AL-TEACHER TOOL | TASK SPLITTER
--------------------------------
Web tool sederhana untuk membantu siswa memecah tugas besar menjadi langkah-langkah kecil.

🧩 CARA PAKAI (LOKAL)
1. Buka file "index.html" di browser (double click).
2. Ketik deskripsi tugas dan jumlah hari → klik "Buat Rencana Belajar".

🌐 CARA HOSTING ONLINE (GITHUB PAGES)
1. Buat akun di https://github.com/
2. Klik "New Repository" → beri nama: task-splitter
3. Upload file index.html dan style.css
4. Masuk ke Settings → Pages → pilih "Deploy from branch" → branch "main"
5. Tunggu ±1 menit, lalu buka: https://username.github.io/task-splitter/

🚀 CARA HOSTING CEPAT (NETLIFY)
1. Buka https://app.netlify.com/drop
2. Drag & drop folder berisi index.html dan style.css
3. Netlify akan langsung memberi URL seperti:
   https://alteacher-task-splitter.netlify.app

Dibuat oleh Alfian Akbar
© 2025 Al-Teacher Tool
